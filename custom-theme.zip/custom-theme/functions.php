<?php
// Enqueue styles and scripts
function custom_theme_enqueue_scripts() {
    // Enqueue main stylesheet
    wp_enqueue_style( 'main-style', get_template_directory_uri() . '/assets/css/styles.css', array(), '1.0', 'all' );
    
    // Enqueue main JavaScript file
    wp_enqueue_script('theme-scripts', get_template_directory_uri() . '/assets/js/scripts.js', array(), null, true);
}

// Hook into the wp_enqueue_scripts action
add_action( 'wp_enqueue_scripts', 'custom_theme_enqueue_scripts' );

// Include other theme files for modular functionality
require get_template_directory() . '/inc/theme-setup.php';         // Theme setup
require get_template_directory() . '/inc/custom-post-types.php';   // Custom post types
require get_template_directory() . '/inc/api-endpoints.php';       // Custom REST API endpoints

// Clean up theme-specific data upon deactivation
function custom_theme_cleanup() {
    // Example: Delete custom theme options
    delete_option('custom_theme_option_name');

    // Remove transients if any were set
    delete_transient('custom_theme_transient_name');
}
add_action('switch_theme', 'custom_theme_cleanup');
