<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title><?php wp_title(); ?></title>
    <?php wp_head(); ?> <!-- WordPress head -->
</head>

<body <?php body_class(); ?>>
    <header>
        <div class="site-header-container">
            <!-- Site Title or Logo -->
            <div class="site-title">
                <a href="<?php echo esc_url(home_url('/')); ?>"><?php echo esc_html(get_bloginfo('name')); ?></a>
            </div>

            <!-- Mobile Menu Toggle Button -->
            <div class="menu-toggle" id="mobile-menu-toggle">
                <span></span>
                <span></span>
                <span></span>
            </div>

            <!-- Primary Navigation Menu -->
            <nav class="site-navigation" id="primary-menu">
                <?php
                wp_nav_menu( array(
                    'theme_location' => 'primary',  // Primary menu location
                    'menu_class'     => 'primary-menu',  // CSS class for styling
                    'container'      => false,  // No additional HTML container
                    'depth'          => 2,  // Supports dropdown for submenus
                ) );
                ?>
            </nav>
        </div>
    </header>

</body>
</html>
