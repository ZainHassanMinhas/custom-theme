document.addEventListener('DOMContentLoaded', function() {
    // Smooth scrolling for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth'
                });
            }
        });
    });

    // Mobile Menu Toggle
    const mobileMenuToggle = document.getElementById('mobile-menu-toggle');
    const primaryMenu = document.getElementById('primary-menu');

    if (mobileMenuToggle && primaryMenu) {
        // Toggle the visibility of the main menu
        mobileMenuToggle.addEventListener('click', function() {
            primaryMenu.classList.toggle('active');
            mobileMenuToggle.classList.toggle('active');
        });

        // Submenu toggle for mobile
        const menuItemsWithSubmenu = primaryMenu.querySelectorAll('.menu-item-has-children > a');
        
        menuItemsWithSubmenu.forEach(menuItem => {
            menuItem.addEventListener('click', function(e) {
                e.preventDefault(); // Prevent the link from navigating
                const submenu = menuItem.nextElementSibling; // Get the submenu
                if (submenu) {
                    submenu.classList.toggle('submenu-active'); // Toggle the active class
                }
            });
        });
    }
});

// To Fetch JSON Data Using API EndPoint.
document.addEventListener('DOMContentLoaded', function() {
    // Check if the current URL matches the target page
    if (window.location.pathname === '/wp-json/custom-theme/v1/projects/') { // Adjust this path accordingly
        fetch('http://custom-project.local/wp-json/custom-theme/v1/projects/')
            .then(response => response.json())
            .then(data => {
                const projectList = document.createElement('div');
                projectList.classList.add('project-list');

                data.forEach(project => {
                    const projectItem = document.createElement('div');
                    projectItem.classList.add('project-item');

                    projectItem.innerHTML = `
                        <h2>${project.title}<br></h2>
                        <p><strong>URL:</strong> <a href="${project.url}" target="_blank">${project.url}</a></p>
                        <p><strong>Start Date:</strong> ${project.start_date}</p>
                        <p><strong>End Date:</strong> ${project.end_date}</p>
                    `;

                    projectList.appendChild(projectItem);
                });

                document.body.appendChild(projectList); // Append to the body or any specific container
            })
            .catch(error => console.error('Error fetching project data:', error));
    }
});

