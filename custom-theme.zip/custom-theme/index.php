<?php get_header(); ?> <!-- Include header.php -->

<main>
    <!-- Main heading -->
    <h1>Welcome to this Custom Theme</h1>

    <?php if (have_posts()) : ?> 
        <!-- Loop through available posts -->
        <div class="post-list">
            <?php while (have_posts()) : the_post(); ?>
                <!-- Post item -->
                <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
                    <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>

                    <!-- Post excerpt -->
                    <div class="entry">
                        <?php the_excerpt(); ?>
                    </div>
                </article>
            <?php endwhile; ?>
        </div>

        <?php
        // Pagination for posts
        the_posts_pagination(array(
            'mid_size' => 2, // Number of page links around the current page
            'prev_text' => __('&laquo;', 'textdomain'), // Previous page link
            'next_text' => __('&raquo;', 'textdomain'), // Next page link
        ));
        ?>
    <?php else : ?>
        <!-- Message if no posts are found -->
        <p><?php _e('No posts found.', 'textdomain'); ?></p>
    <?php endif; ?>
</main>

<?php get_footer(); ?> <!-- Include footer.php -->
