<?php
/*
Template Name: Custom Blog
*/
get_header(); // Include the header
?>

<!-- Blog Page Content -->
<div class="blog-container">

    <?php
    // Start the Loop for blog posts
    if (have_posts()) :
    ?>

    <?php
        while (have_posts()) : the_post();
    ?>
            <article class="post">
                <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                <div class="post-excerpt">
                    <?php the_excerpt(); ?> <!-- Display the excerpt of the post -->
                </div>
                <div class="post-meta">
                    <p><?php esc_html_e('Posted on:', 'custom-theme'); ?> <?php echo esc_html(get_the_date()); ?></p>
                </div>
            </article>

    <?php
        endwhile;

        // Pagination for blog posts
        the_posts_pagination(array(
            'mid_size' => 2,
            'prev_text' => __('&laquo; Previous', 'custom-theme'),
            'next_text' => __('Next &raquo;', 'custom-theme'),
        ));

    else :
        echo '<p>' . esc_html__('No posts found.', 'custom-theme') . '</p>'; // Message if no posts are found
    endif;
    ?>
</div>

<?php
get_footer(); // Include the footer
?>
