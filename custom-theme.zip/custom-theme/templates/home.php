<?php
/*
Template Name: Custom Home
*/

get_header(); // Include the header
?>

<main>
    <section class="hero">
        <h1><?php esc_html_e('Welcome to Our Website', 'custom-theme'); ?></h1>
        <p><?php esc_html_e('Professional Theme for IKONIC', 'custom-theme'); ?></p>
    </section>
</main>

<?php
get_footer(); // Include the footer
?>
