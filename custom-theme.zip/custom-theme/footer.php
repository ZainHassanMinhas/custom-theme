<footer>
    <div class="footer-content">
        <p>&copy; <?php echo esc_html( date('Y') ); ?> Custom Theme. All rights reserved.</p>
    </div>
    <?php wp_footer(); ?>
</footer>
</body>
</html>
