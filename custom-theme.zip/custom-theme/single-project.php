<?php
get_header(); ?>

<div class="project-details">
    <?php
    if (have_posts()) :
        while (have_posts()) : the_post();
            // Display the title
            the_title('<h1>', '</h1>');

            // Display custom fields
            $project_name = get_field('project_name');
            $project_description = get_field('project_description');
            $project_start_date = get_field('project_start_date');
            $project_end_date = get_field('project_end_date');
            $project_url = get_field('project_url');
            ?>

<?php

// Get the URL for the projects archive page
$projects_archive_url = get_post_type_archive_link('project');
?>
<!-- button -->
<div class="back-to-archive">
    <a href="<?php echo esc_url($projects_archive_url); ?>" class="btn-back">
        <?php esc_html_e('Back to Projects', 'textdomain'); ?>
    </a>
</div>
            
            <table>
                <tr>
                    <td><strong>Project Name:</strong></td>
                    <td><?php echo esc_html($project_name); ?></td>
                </tr>
                <tr>
                    <td><strong>Description:</strong></td>
                    <td><?php echo esc_html($project_description); ?></td>
                </tr>
                <tr>
                    <td><strong>Start Date:</strong></td>
                    <td><?php echo esc_html($project_start_date); ?></td>
                </tr>
                <tr>
                    <td><strong>End Date:</strong></td>
                    <td><?php echo esc_html($project_end_date); ?></td>
                </tr>
                <tr>
                    <td><strong>Project Link:</strong></td>
                    <td><a href="<?php echo esc_url($project_url); ?>" target="_blank" rel="noopener noreferrer">View Project</a></td>
                </tr>
            </table>
            
            <?php
        endwhile;
    else :
        echo '<p>' . esc_html__('No project found.', 'textdomain') . '</p>';
    endif;
    ?>
</div>

<?php get_footer(); ?>
