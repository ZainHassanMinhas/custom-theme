<?php
get_header(); // Include the header

if (have_posts()) :
    while (have_posts()) : the_post(); ?>
        <div class="single-post-container">
            <h1><?php the_title(); ?></h1> <!-- Display the post title -->
            <div class="post-meta">
                <p><?php esc_html_e('Posted on:', 'custom-theme'); ?> <?php echo esc_html(get_the_date()); ?></p>
            </div>
            <div class="post-content">
                <?php the_content(); ?> <!-- Display the full post content -->
            </div>

            <!-- Add a back button to return to the blog page -->
            <a href="<?php echo esc_url(home_url('/blog')); ?>" class="back-to-blog"><?php esc_html_e('Back to Blog', 'custom-theme'); ?></a>
        </div>
    <?php endwhile;
else :
    echo '<p>' . esc_html__('No posts found.', 'custom-theme') . '</p>'; // Message if no posts are found
endif;

get_footer(); // Include the footer
?>
