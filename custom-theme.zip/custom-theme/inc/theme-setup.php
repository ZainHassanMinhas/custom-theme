<?php

// Set up theme features
function custom_theme_setup() {
    // Add support for dynamic title tags
    add_theme_support('title-tag');
    
    // Add support for post thumbnails
    add_theme_support('post-thumbnails');
    
    // Register a primary menu
    register_nav_menus(array(
        'primary' => __('Primary Menu', 'custom-theme'),
    ));

    // Add HTML5 support for forms, comment forms, galleries, and captions
    add_theme_support('html5', array('search-form', 'comment-form', 'gallery', 'caption'));

    // Add support for custom logo with flexible width and height
    add_theme_support('custom-logo', array(
        'height'      => 100,
        'width'       => 400,
        'flex-height' => true,
        'flex-width'  => true,
    ));

    // Add support for selective refresh for widgets in the customizer
    add_theme_support('customize-selective-refresh-widgets');
}

// Hook theme setup into after_setup_theme action
add_action('after_setup_theme', 'custom_theme_setup');

// Keep only the Customize button in the theme preview
function customize_only_theme_preview() {
    // Remove the patterns and menu buttons in the customizer preview
    add_filter('customize_controls_enqueue_scripts', function() {
        ?>
        <script type="text/javascript">
            jQuery(document).ready(function($) {
                // Hide the patterns and menu buttons
                $('.add-patterns, .add-menu').hide();
            });
        </script>
        <?php
    });
}

add_action('customize_preview_init', 'customize_only_theme_preview');

?>
