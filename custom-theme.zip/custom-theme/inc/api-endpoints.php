<?php

// Register a custom REST API endpoint to get project data
function custom_projects_api_endpoint() {
    register_rest_route('custom-theme/v1', '/projects/', array(
        'methods'  => 'GET',
        'callback' => 'get_project_data',
    ));
}

// Hook into the REST API to register the endpoint
add_action('rest_api_init', 'custom_projects_api_endpoint');

// Callback function to fetch project data
function get_project_data() {
    // Ensure this is only called during a REST request
    if (!defined('REST_REQUEST') || !REST_REQUEST) {
        return new WP_Error('rest_forbidden', esc_html__('You cannot access this endpoint.', 'custom-theme'), array('status' => 401));
    }
    
    $args = array(
        'post_type' => 'project', // Ensure this matches your custom post type
        'posts_per_page' => -1
    );
    
    $projects = get_posts($args);

    // Start building the data array
    $data = array();

    foreach ($projects as $project) {
        $start_date_raw = get_post_meta($project->ID, 'project_start_date', true);
        $end_date_raw = get_post_meta($project->ID, 'project_end_date', true);

        // Format dates for readability
        $start_date = DateTime::createFromFormat('Ymd', $start_date_raw)->format('d F Y');
        $end_date = DateTime::createFromFormat('Ymd', $end_date_raw)->format('d F Y');

        // Get the project URL without escaped characters
        $project_url = esc_url(get_post_meta($project->ID, 'project_url', true));

        $data[] = array(
            'title'         => esc_html(get_the_title($project->ID)),
            'url'           => $project_url, // URL is now formatted correctly
            'start_date'    => $start_date,
            'end_date'      => $end_date,
        );
    }

    // Return the data as a JSON response
    return new WP_REST_Response($data, 200, array('Content-Type' => 'application/json'));
}

?>
