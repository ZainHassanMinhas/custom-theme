<?php

// Register Custom Post Type: Projects
function custom_post_type_projects() {
    $labels = array(
        'name'                  => _x( 'Projects', 'Post Type General Name', 'custom-theme' ),
        'singular_name'         => _x( 'Project', 'Post Type Singular Name', 'custom-theme' ),
        'menu_name'             => __( 'Projects', 'custom-theme' ),
        'all_items'             => __( 'All Projects', 'custom-theme' ),
        'add_new_item'          => __( 'Add New Project', 'custom-theme' ),
        'edit_item'             => __( 'Edit Project', 'custom-theme' ),
        'new_item'              => __( 'New Project', 'custom-theme' ),
        'view_item'             => __( 'View Project', 'custom-theme' ),
        'search_items'          => __( 'Search Projects', 'custom-theme' ),
        'not_found'             => __( 'No projects found', 'custom-theme' ),
        'not_found_in_trash'    => __( 'No projects found in Trash', 'custom-theme' ),
    );
    
    $args = array(
        'label'                 => __( 'Project', 'custom-theme' ),
        'labels'                => $labels,
        'supports'              => array( 'title', 'editor', 'thumbnail', 'custom-fields' ),
        'public'                => true,
        'menu_position'         => 5,
        'has_archive'           => true,
        'show_in_rest'          => true,
        'menu_icon'             => 'dashicons-portfolio',
    );
    
    register_post_type( 'project', $args );
}

// Hook into the 'init' action to add custom post type support
add_action( 'init', 'custom_post_type_projects' );
?>
