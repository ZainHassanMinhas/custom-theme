=== Custom Theme ===
Contributors: Zain Minhas
Tags: custom, theme, WordPress
Requires at least: 5.0
Tested up to: 6.0
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

## Overview
This custom WordPress theme is developed for a IKONIC as an assessment, featuring custom post types, REST API integration, and customizable templates. The theme is lightweight, responsive, and follows WordPress coding standards. It also includes features like project listing, a custom blog page, single post layouts, and more.

## Installation

1. **Download & Upload the Theme**  
   Download the theme folder and upload it via the WordPress admin dashboard:  
   `Appearance` > `Themes` > `Add New` > `Upload Theme`  
   Select the theme's .zip file and click `Install Now`.

2. **Activate the Theme**  
   Once uploaded, click `Activate` to enable the theme.

3. **Install Required Plugins**  
   Ensure all necessary plugins are installed, Advanced Custom Fields (ACF) for custom fields functionality.

## Theme Features

### 1. Custom Post Type: Projects
The theme includes a custom post type `project` to manage project entries.

#### Features:
- Project name
- Project description
- Start and end dates (ACF)
- External project URL (ACF)
  
  Projects are displayed on the custom project archive page (`archive-project.php`) with an optional filter based on project start and end dates.
  Single project entries displayed on using single-project.php

### 2. Custom Fields using the ACF Plugin


### 3. Custom Home & Blog Templates
The theme includes a custom home and blog page template (`templates/home.php`), (`templates/blog.php`).

- **Template Name**: Custom Home
- **Usage**: When creating a page, select `Custom Home` as the template. 

Same for the blog page, create 2 page home and blog assign the custom templates. And goto Customize > Homepage settings and select the pages.

### 4. Single Post Layout (`single.php`)
Posts open in a detailed single post view.

### 5. Theme Customization
This theme supports the following customization features:
- **Custom Logo**: Upload and customize the site logo (`Appearance` > `Customize` > `Site Identity`).
- **Primary Menu**: Register a custom navigation menu (`Appearance` > `Menus`).
- **Post Thumbnails**: Featured images for posts and pages.

### 6. Custom API Endpoints
A custom endpoint is registered to fetch project data. You can access it via:

/wp-json/custom-theme/v1/projects/


### 7. Pagination
Built-in pagination is used on blog post listings and project archives to allow easy navigation between pages.

### 8. Responsive Design
The theme is fully responsive, ensuring a seamless experience across devices. Media queries have been used for mobile responsiveness.

### 9. Custom Filters on Project Archive
On the projects archive page (`archive-project.php`), there is a filter functionality that allows users to filter projects by start and end dates.

### 10. Minimal Button Options on Theme Preview
The theme preview in the admin area shows only the `Customize` button, removing unnecessary buttons like `Patterns` and `Menus` for a cleaner preview experience.

## Theme Files Structure

```
/assets/                # CSS and JS assets
  /css/
    styles.css          # Main stylesheet
  /js/
    scripts.js          # Main JavaScript file
/inc/                   # Includes PHP files for additional functionality
  /theme-setup.php      # Theme setup and support
  /custom-post-types.php# Custom post types registration
  /api-endpoints.php    # REST API endpoints
/templates/             # Custom page templates
  blog.php              # Custom blog page template
  archive-project.php   # Projects archive template
  single-project.php    # Single project page template
index.php               # Main index file
header.php              # Header template
footer.php              # Footer template
single.php              # Single post layout
style.css               # Theme's main stylesheet
functions.php           # Theme's main functions file
README.txt              # This documentation
```

## Customization Guide

### Menus
1. Go to `Appearance > Menus` to create a new menu.
2. Assign the menu to the `Primary` location for it to appear on the site.

### Adding Projects
1. Navigate to `Projects > Add New`.
2. Fill in the project details, including name, description, start date, end date, and project URL.

Make sure before creating a Project, install acf plugin and make desired custom fields.

== Changelog ==

= 1.0 =
* Initial release of the custom theme.

== Credits ==

Developed by Zain Minhas
