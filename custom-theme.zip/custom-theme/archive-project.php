<?php get_header(); ?>

<div class="project-archive">
    <h1><?php esc_html_e('Projects', 'textdomain'); ?></h1>

    <!-- Filter Form -->
    <form method="GET" action="">
        <label for="start_date"><?php esc_html_e('Start Date:', 'textdomain'); ?></label>
        <input type="date" name="start_date" id="start_date" required>
        
        <label for="end_date"><?php esc_html_e('End Date:', 'textdomain'); ?></label>
        <input type="date" name="end_date" id="end_date" required>
        
        <input type="submit" value="<?php esc_html_e('Filter Projects', 'textdomain'); ?>">
    </form>

    <?php 
    // Query based on the filter inputs
    if (isset($_GET['start_date']) && isset($_GET['end_date'])) {
        $start_date = sanitize_text_field($_GET['start_date']);
        $end_date = sanitize_text_field($_GET['end_date']);
        
        $args = array(
            'post_type' => 'project',
            'posts_per_page' => -1,
            'meta_query' => array(
                'relation' => 'AND',
                array(
                    'key' => 'project_start_date',
                    'value' => $start_date,
                    'compare' => '>=',
                    'type' => 'DATE'
                ),
                array(
                    'key' => 'project_end_date',
                    'value' => $end_date,
                    'compare' => '<=',
                    'type' => 'DATE'
                ),
            ),
        );
    } else {
        // Default query
        $args = array(
            'post_type' => 'project',
            'posts_per_page' => -1,
        );
    }

    // Query
    $projects = new WP_Query($args);
    
    if ($projects->have_posts()) : ?>
        <table>
            <thead>
                <tr>
                    <th><?php esc_html_e('Project Name', 'textdomain'); ?></th>
                    <th><?php esc_html_e('Description', 'textdomain'); ?></th>
                    <th><?php esc_html_e('Start Date', 'textdomain'); ?></th>
                    <th><?php esc_html_e('End Date', 'textdomain'); ?></th>
                    <th><?php esc_html_e('Link', 'textdomain'); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php
                while ($projects->have_posts()) : $projects->the_post();
                    // ACF fields
                    $project_name = get_field('project_name');
                    $project_description = get_field('project_description');
                    $project_start_date = get_field('project_start_date');
                    $project_end_date = get_field('project_end_date');
                    $project_url = get_field('project_url');
                ?>
                    <tr>
                        <td><a href="<?php echo esc_url(get_permalink()); ?>"><?php echo esc_html($project_name); ?></a></td>
                        <td><?php echo esc_html($project_description); ?></td>
                        <td><?php echo esc_html($project_start_date); ?></td>
                        <td><?php echo esc_html($project_end_date); ?></td>
                        <td><a href="<?php echo esc_url($project_url); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e('View Project', 'textdomain'); ?></a></td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>

        <!-- Pagination -->
        <div class="pagination">
            <?php the_posts_pagination(); ?>
        </div>
    <?php else : ?>
        <p><?php esc_html_e('No projects found.', 'textdomain'); ?></p>
    <?php endif; ?>

    <?php wp_reset_postdata(); // Reset the query ?>
</div>

<?php get_footer(); ?>
